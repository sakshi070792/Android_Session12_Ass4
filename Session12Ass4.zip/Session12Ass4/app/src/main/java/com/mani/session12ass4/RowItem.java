package com.mani.session12ass4;

/**
 * Created by sakshi.banger on 13-10-2016.
 */
public class RowItem {
    private String title;
    private String  titledesc;
    private int icon;
    public RowItem(String title,String titledesc,int icon){
        this.title=title;
        this.titledesc=titledesc;
        this.icon=icon;
    }

    public String getTitle() {
        return title;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getTitledesc() {

        return titledesc;
    }

    public void setTitledesc(String titledesc) {
        this.titledesc = titledesc;
    }

    public void setTitle(String title) {
        this.title = title;

    }
}
