package com.mani.session12ass4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by sakshi.banger on 13-10-2016.
 */
public class CustomAdapter  extends BaseAdapter {
    Context mcontext;
    List<RowItem> rowitem;
    CustomAdapter(Context context,List<RowItem> rowitem){
        mcontext=context;
        this.rowitem=rowitem;

    }


    @Override
    public int getCount() {
        return rowitem.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView=LayoutInflater.from(mcontext).inflate(R.layout.list_item,null);
        ImageView imgicon=(ImageView)convertView.findViewById(R.id.icon);
        TextView title=(TextView)convertView.findViewById(R.id.tvtitle);
        TextView titledesc=(TextView)convertView.findViewById(R.id.tvtitledesc);
        RowItem row_pos=rowitem.get(position);
        imgicon.setImageResource(row_pos.getIcon());
        title.setText(row_pos.getTitle());
        titledesc.setText(row_pos.getTitledesc());
        return convertView;



    }
}
