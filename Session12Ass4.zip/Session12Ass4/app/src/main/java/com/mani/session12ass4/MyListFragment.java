package com.mani.session12ass4;

import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sakshi.banger on 14-10-2016.
 */
public class MyListFragment extends android.app.Fragment implements AdapterView.OnItemClickListener {
    String menutitles[];
   TypedArray menuicon;
    String menudesc[];
    CustomAdapter adapter;
    private List<RowItem> rowitems;
    ListView lvlist;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.list_fragment,container,false);
        lvlist= (ListView) view.findViewById(R.id.lvlist);
        return view;


    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        menutitles=getResources().getStringArray(R.array.titles);
        menuicon=getResources().obtainTypedArray(R.array.icons);
        menudesc=getResources().getStringArray(R.array.titledesc);
        rowitems=new ArrayList<RowItem>();
        for(int i=0;i<menutitles.length;i++)
        {
            RowItem items=new RowItem(menutitles[i],menudesc[i],menuicon.getResourceId(i,-1));
            rowitems.add(items);
        }
        adapter=new CustomAdapter(getActivity(),rowitems);
        lvlist.setAdapter(adapter);
        lvlist.setOnItemClickListener(this);

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(getActivity(),menutitles[position],Toast.LENGTH_SHORT).show();
    }
}
